export interface Joueur{
    nom: string,
    score: number
}